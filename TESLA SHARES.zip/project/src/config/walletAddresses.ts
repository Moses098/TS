export const WALLET_ADDRESSES = {
  bitcoin: 'bc1qttz4avwev4lzn7zxznxd79s4mshedelaxwpqsx',
  ethereum: '0x920032bc5b44988570369349cAc0a69171a786CA',
  solana: 'Dby6E6ABwMg4aR2j8KvTzkdY7kz1kVYLKbMN3N7dDTTm',
  ton: 'UQDBIyFkbvzRm-F3B6Q57FesbDAvPiZ7yN6hsKTJGs4Z6F6o',
  usdt: '0xcff4c29312598a572512fcabfa4ea5629a8b978c'
};