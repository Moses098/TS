export const SITE_CONFIG = {
  name: 'TESLA SHARES INVESTMENT',
  description: 'Invest in Tesla shares with cryptocurrency',
  welcomeBonus: {
    initialAmount: 2000,
    bonusAmount: 5000,
    requiredDeposit: 3000,
  },
  withdrawalLimit: 10000,
} as const;