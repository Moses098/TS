import React from 'react';
import { useAuthStore } from '../store/authStore';
import { CryptoCard } from '../components/CryptoCard';
import { TeslaSharesCard } from '../components/TeslaSharesCard';
import { CustomerSupport } from '../components/CustomerSupport';
import { AssetSummary } from '../components/dashboard/AssetSummary';
import { TransactionHistory } from '../components/dashboard/TransactionHistory';
import { CRYPTO_CONFIG } from '../config/cryptoConfig';

export const Dashboard: React.FC = () => {
  const { user } = useAuthStore();

  if (!user) return null;

  const showRecoveryPhrase = !user.profile?.hasSeenPhrase && user.phrase;

  return (
    <div className="space-y-8">
      {showRecoveryPhrase && (
        <div className="bg-red-900/30 border border-red-700/50 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <h3 className="text-xl font-bold text-white">Your Recovery Phrase</h3>
          </div>
          <p className="text-red-200 font-mono bg-red-950/50 p-4 rounded-lg break-all">
            {user.phrase}
          </p>
          <p className="text-red-400 text-sm mt-4">
            IMPORTANT: Save this phrase securely. You'll need it to recover your account. 
            This message will only appear once.
          </p>
        </div>
      )}

      <AssetSummary user={user} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.keys(CRYPTO_CONFIG).map((crypto) => (
          <CryptoCard
            key={crypto}
            name={crypto as keyof typeof CRYPTO_CONFIG}
            balance={user.balance[crypto as keyof typeof user.balance]}
            user={user}
          />
        ))}
      </div>

      <TeslaSharesCard user={user} />
      
      <TransactionHistory user={user} />
      
      {user.role === 'customer' && <CustomerSupport />}
    </div>
  );
};