import React from 'react';
import { Hero } from '../components/landing/Hero';
import { MarketTrends } from '../components/landing/MarketTrends';
import { Features } from '../components/landing/Features';
import { AnimatedBackground } from '../components/AnimatedBackground';
import { FloatingCryptoIcons } from '../components/FloatingCryptoIcons';

export const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-black">
      <AnimatedBackground />
      <FloatingCryptoIcons />
      <Hero />
      <MarketTrends />
      <Features />
    </div>
  );
};