import React, { useState } from 'react';
import { LoginForm } from '../components/auth/LoginForm';
import { Rocket } from 'lucide-react';

export const Login: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<'none' | 'admin' | 'customer'>('none');

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-red-900 to-gray-900">
      <div className="w-full max-w-md p-8 bg-gray-800/50 backdrop-blur-sm rounded-xl shadow-lg border border-gray-700">
        <div className="flex flex-col items-center mb-8">
          <Rocket className="text-red-500 w-16 h-16" />
          <h1 className="mt-4 text-3xl font-bold text-white">
            TESLA ELON MUSK
          </h1>
          <p className="mt-2 text-gray-400">
            Crypto Investment Platform
          </p>
        </div>

        {selectedRole === 'none' ? (
          <div className="space-y-4">
            <button
              onClick={() => setSelectedRole('customer')}
              className="w-full py-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
            >
              Customer Login
            </button>
            <button
              onClick={() => setSelectedRole('admin')}
              className="w-full py-4 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors font-medium"
            >
              Admin Login
            </button>
          </div>
        ) : (
          <LoginForm
            isAdmin={selectedRole === 'admin'}
            onBack={() => setSelectedRole('none')}
          />
        )}
      </div>
    </div>
  );
};