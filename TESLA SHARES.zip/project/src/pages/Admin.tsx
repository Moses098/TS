import React, { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { useMessageStore } from '../store/messageStore';
import { CustomerList } from '../components/admin/CustomerList';
import { ProfileEditor } from '../components/admin/ProfileEditor';
import { BalanceEditor } from '../components/admin/BalanceEditor';
import { TransactionEditor } from '../components/admin/TransactionEditor';
import { UserActions } from '../components/admin/UserActions';
import { Announcement } from '../components/admin/Announcement';
import { MessageCircle, Users, History, Settings } from 'lucide-react';

export const Admin: React.FC = () => {
  const { user, users } = useAuthStore();
  const { getMessages, addMessage } = useMessageStore();
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [replyMessage, setReplyMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'profile' | 'balance' | 'transactions' | 'support' | 'actions'>('profile');

  if (user?.role !== 'admin') return null;

  const customers = users.filter((u) => u.role === 'customer');
  const selectedCustomer = customers.find((c) => c.id === selectedUser);
  const customerMessages = selectedUser ? getMessages(selectedUser) : [];

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMessage.trim() || !selectedUser) return;

    addMessage(selectedUser, replyMessage, true);
    setReplyMessage('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-1">
        <CustomerList
          customers={customers}
          selectedUser={selectedUser}
          onSelectUser={setSelectedUser}
        />
        <div className="mt-8">
          <Announcement />
        </div>
      </div>

      {selectedCustomer ? (
        <div className="lg:col-span-2">
          <div className="bg-gray-800 rounded-lg p-6">
            <div className="flex border-b border-gray-700 mb-6">
              <button
                onClick={() => setActiveTab('profile')}
                className={`px-4 py-2 ${
                  activeTab === 'profile'
                    ? 'border-b-2 border-red-500 text-white'
                    : 'text-gray-400'
                }`}
              >
                <Users className="inline-block mr-2" size={18} />
                Profile
              </button>
              <button
                onClick={() => setActiveTab('balance')}
                className={`px-4 py-2 ${
                  activeTab === 'balance'
                    ? 'border-b-2 border-red-500 text-white'
                    : 'text-gray-400'
                }`}
              >
                Balance
              </button>
              <button
                onClick={() => setActiveTab('transactions')}
                className={`px-4 py-2 ${
                  activeTab === 'transactions'
                    ? 'border-b-2 border-red-500 text-white'
                    : 'text-gray-400'
                }`}
              >
                <History className="inline-block mr-2" size={18} />
                Transactions
              </button>
              <button
                onClick={() => setActiveTab('support')}
                className={`px-4 py-2 ${
                  activeTab === 'support'
                    ? 'border-b-2 border-red-500 text-white'
                    : 'text-gray-400'
                }`}
              >
                <MessageCircle className="inline-block mr-2" size={18} />
                Support
              </button>
              <button
                onClick={() => setActiveTab('actions')}
                className={`px-4 py-2 ${
                  activeTab === 'actions'
                    ? 'border-b-2 border-red-500 text-white'
                    : 'text-gray-400'
                }`}
              >
                <Settings className="inline-block mr-2" size={18} />
                Actions
              </button>
            </div>

            {activeTab === 'profile' && <ProfileEditor customer={selectedCustomer} />}
            {activeTab === 'balance' && <BalanceEditor customer={selectedCustomer} />}
            {activeTab === 'transactions' && <TransactionEditor customer={selectedCustomer} />}
            {activeTab === 'actions' && <UserActions customer={selectedCustomer} />}
            {activeTab === 'support' && (
              <div className="space-y-4">
                <div className="h-64 overflow-y-auto bg-gray-900 rounded-lg p-4 space-y-4">
                  {customerMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.isAdmin ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`rounded-lg px-4 py-2 max-w-[80%] ${
                          msg.isAdmin
                            ? 'bg-red-600 text-white'
                            : 'bg-gray-700 text-white'
                        }`}
                      >
                        {msg.isAnnouncement && (
                          <span className="text-xs font-semibold bg-yellow-500 text-black px-2 py-1 rounded mb-2 inline-block">
                            Announcement
                          </span>
                        )}
                        <p>{msg.content}</p>
                        <span className="text-xs opacity-75">
                          {new Date(msg.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <form onSubmit={handleSendReply} className="flex gap-2">
                  <input
                    type="text"
                    value={replyMessage}
                    onChange={(e) => setReplyMessage(e.target.value)}
                    placeholder="Type your reply..."
                    className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    Send Reply
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="lg:col-span-2 flex items-center justify-center h-64 bg-gray-800 rounded-lg">
          <p className="text-gray-400">Select a customer to view details</p>
        </div>
      )}
    </div>
  );
};