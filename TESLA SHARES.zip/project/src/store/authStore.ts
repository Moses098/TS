import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';

interface AuthState {
  user: User | null;
  users: User[];
  setUser: (user: User | null) => void;
  updateUserProfile: (userId: string, profile: User['profile']) => void;
  updateUserBalance: (userId: string, balance: User['balance']) => void;
  updateUserStatus: (userId: string, status: 'active' | 'suspended' | 'banned') => void;
  deleteUser: (userId: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      users: [],
      setUser: (user) =>
        set((state) => ({
          user,
          users:
            user && user.role === 'customer'
              ? [...state.users.filter((u) => u.id !== user.id), user]
              : state.users,
        })),
      updateUserProfile: (userId, profile) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === userId ? { ...u, profile: { ...u.profile, ...profile } } : u
          ),
        })),
      updateUserBalance: (userId, balance) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === userId ? { ...u, balance } : u
          ),
        })),
      updateUserStatus: (userId, status) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === userId ? { ...u, status } : u
          ),
        })),
      deleteUser: (userId) =>
        set((state) => ({
          users: state.users.filter((u) => u.id !== userId),
        })),
      logout: () => set({ user: null }),
    }),
    {
      name: 'auth-storage',
    }
  )
);