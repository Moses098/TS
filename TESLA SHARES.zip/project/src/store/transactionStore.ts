import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Transaction } from '../types';

interface TransactionState {
  transactions: Record<string, Transaction[]>;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  getTransactions: (userId: string) => Transaction[];
}

export const useTransactionStore = create<TransactionState>()(
  persist(
    (set, get) => ({
      transactions: {},
      addTransaction: (transaction) => {
        const newTransaction: Transaction = {
          ...transaction,
          id: crypto.randomUUID(),
        };
        set((state) => ({
          transactions: {
            ...state.transactions,
            [transaction.userId]: [
              ...(state.transactions[transaction.userId] || []),
              newTransaction,
            ],
          },
        }));
      },
      getTransactions: (userId) => get().transactions[userId] || [],
    }),
    {
      name: 'transaction-storage',
    }
  )
);