export interface User {
  id: string;
  username: string;
  role: 'admin' | 'customer';
  status?: 'active' | 'suspended' | 'banned';
  phrase?: string;
  balance: {
    bitcoin: number;
    ethereum: number;
    solana: number;
    ton: number;
    usdt: number;
    tesla: number;
  };
  profile?: {
    email?: string;
    fullName?: string;
    country?: string;
    joinedAt: string;
    hasSeenPhrase?: boolean;
  };
}

export interface Message {
  id: string;
  userId: string;
  content: string;
  timestamp: string;
  isAdmin: boolean;
  isAnnouncement?: boolean;
}

export interface Transaction {
  id: string;
  userId: string;
  asset: string;
  type: 'deposit' | 'withdrawal' | 'transfer' | 'bonus';
  amount: number;
  timestamp: string;
  status: 'completed' | 'pending' | 'failed';
  description?: string;
}