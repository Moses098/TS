import React, { useState } from 'react';
import { hasMinimumBalance } from '../utils/balanceUtils';
import { User } from '../types';
import { TrendingUp, AlertCircle } from 'lucide-react';
import { useCryptoRates } from '../services/cryptoRates';

interface TeslaSharesCardProps {
  user: User;
}

export const TeslaSharesCard: React.FC<TeslaSharesCardProps> = ({ user }) => {
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const { rates } = useCryptoRates();
  const teslaPrice = user.role === 'admin' ? 0 : 180.75;

  const hasDeposited = Object.entries(user.balance).some(([asset, amount]) => {
    if (asset === 'bitcoin' && amount === 0.05) return false; // Registration bonus
    return amount > 0;
  });

  const handleBuyShares = () => {
    if (!hasDeposited) {
      setErrorMessage('Please make a deposit before buying Tesla shares');
      setShowError(true);
      setTimeout(() => setShowError(false), 3000);
      return;
    }

    if (!hasMinimumBalance(user.balance, rates)) {
      setErrorMessage('Insufficient balance');
      setShowError(true);
      setTimeout(() => setShowError(false), 3000);
      return;
    }
    
    alert('Please contact support to process your Tesla shares purchase.');
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 relative">
      {showError && (
        <div className="absolute top-0 left-0 right-0 bg-red-600 text-white p-2 rounded-t-lg flex items-center justify-center gap-2">
          <AlertCircle size={16} />
          <span className="text-sm">{errorMessage}</span>
        </div>
      )}

      <div className="flex items-center gap-3 mb-4">
        <img
          src="https://logo.clearbit.com/tesla.com"
          alt="Tesla"
          className="w-10 h-10 rounded-full"
        />
        <div>
          <h3 className="text-xl font-bold text-white">Tesla Shares</h3>
          <div className="flex items-center gap-2 mt-1">
            <TrendingUp className="w-4 h-4 text-green-500" />
            <span className="text-sm text-gray-400">
              ${teslaPrice.toLocaleString()}
            </span>
          </div>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-400">Current Holdings</p>
          <p className="text-2xl font-bold text-white">{user.balance.tesla} shares</p>
          <p className="text-sm text-gray-400">
            ≈ ${(user.balance.tesla * teslaPrice).toLocaleString()}
          </p>
        </div>
        <div className="flex flex-col items-end">
          <button
            onClick={handleBuyShares}
            className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
          >
            Buy Shares
          </button>
          {!hasDeposited && (
            <p className="text-sm text-gray-400 mt-2">
              Deposit required to buy shares
            </p>
          )}
        </div>
      </div>
    </div>
  );
};