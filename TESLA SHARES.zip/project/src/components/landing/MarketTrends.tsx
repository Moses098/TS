import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { useCryptoRates } from '../../services/cryptoRates';
import { useSpring, animated } from '@react-spring/web';
import { CRYPTO_CONFIG } from '../../config/cryptoConfig';

export const MarketTrends: React.FC = () => {
  const { rates, isLoading } = useCryptoRates();
  
  const slideIn = useSpring({
    from: { opacity: 0, transform: 'translateY(20px)' },
    to: { opacity: 1, transform: 'translateY(0)' },
    delay: 200,
  });

  return (
    <div className="bg-gray-900 py-16">
      <animated.div style={slideIn} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-white mb-8 text-center">
          Live Market Trends
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(CRYPTO_CONFIG).map(([key, crypto]) => {
            const price = rates[key as keyof typeof rates];
            const isPositive = Math.random() > 0.5; // Simulated trend

            return (
              <div key={key} className="bg-gray-800 rounded-lg p-6 hover:bg-gray-750 transition-colors">
                <div className="flex items-center gap-4">
                  <img
                    src={crypto.logo}
                    alt={crypto.name}
                    className="w-12 h-12"
                  />
                  <div>
                    <h3 className="text-xl font-semibold text-white">
                      {crypto.name}
                    </h3>
                    <p className={crypto.color}>{crypto.symbol}</p>
                  </div>
                </div>
                
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-white">
                      ${isLoading ? '...' : price.toLocaleString()}
                    </span>
                    <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                      {isPositive ? (
                        <TrendingUp className="w-5 h-5 mr-1" />
                      ) : (
                        <TrendingDown className="w-5 h-5 mr-1" />
                      )}
                      <span>{isPositive ? '+2.5%' : '-1.8%'}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </animated.div>
    </div>
  );
};