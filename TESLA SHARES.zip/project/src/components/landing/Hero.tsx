import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Shield, Lock, TrendingUp, Gift } from 'lucide-react';
import { useSpring, animated } from '@react-spring/web';
import { SITE_CONFIG } from '../../config/siteConfig';
import { StylizedTitle } from '../StylizedTitle';

export const Hero: React.FC = () => {
  const navigate = useNavigate();
  const fadeIn = useSpring({
    from: { opacity: 0, transform: 'translateY(20px)' },
    to: { opacity: 1, transform: 'translateY(0)' },
    config: { tension: 280, friction: 20 }
  });

  return (
    <div className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-red-900 opacity-90" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <animated.div style={fadeIn} className="text-center space-y-8">
          <div className="flex flex-col items-center justify-center space-y-8">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/e/e8/Tesla_logo.png"
              alt="Tesla"
              className="h-32 w-auto object-contain mix-blend-screen filter brightness-200"
              style={{ 
                WebkitFilter: 'brightness(200%) contrast(200%)',
                filter: 'brightness(200%) contrast(200%)'
              }}
            />
            <StylizedTitle />
          </div>
          
          <div className="bg-red-600/20 border border-red-500/30 rounded-lg p-6 max-w-2xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Gift className="text-red-500 w-8 h-8" />
              <h2 className="text-2xl font-bold text-white">Special Welcome Offer!</h2>
            </div>
            <p className="text-xl text-red-100">
              Get ${SITE_CONFIG.welcomeBonus.initialAmount} in Bitcoin instantly when you register!
            </p>
            <p className="text-sm text-red-200 mt-2">
              Plus, unlock ${SITE_CONFIG.welcomeBonus.bonusAmount} bonus after depositing ${SITE_CONFIG.welcomeBonus.requiredDeposit}
            </p>
          </div>

          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto">
            Experience the future of investment with our cutting-edge platform.
            Trade Bitcoin, Ethereum, and Tesla shares in one secure place.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mt-8">
            <button
              onClick={() => navigate('/login')}
              className="flex items-center px-8 py-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-lg font-semibold"
            >
              Start Trading
              <ArrowRight className="ml-2 w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-lg">
              <Shield className="w-10 h-10 text-red-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">
                Secure Platform
              </h3>
              <p className="text-gray-400">
                Advanced encryption and security measures to protect your assets
              </p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-lg">
              <Lock className="w-10 h-10 text-red-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">
                Recovery Phrase
              </h3>
              <p className="text-gray-400">
                Secure wallet access with your unique 12-word recovery phrase
              </p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-lg">
              <TrendingUp className="w-10 h-10 text-red-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">
                Live Market Data
              </h3>
              <p className="text-gray-400">
                Real-time cryptocurrency prices and market trends
              </p>
            </div>
          </div>
        </animated.div>
      </div>
    </div>
  );
};