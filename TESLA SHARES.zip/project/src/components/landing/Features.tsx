import React from 'react';
import { Shield, Rocket, MessageCircle, Coins } from 'lucide-react';
import { useSpring, animated } from '@react-spring/web';

export const Features: React.FC = () => {
  const fadeIn = useSpring({
    from: { opacity: 0 },
    to: { opacity: 1 },
    delay: 400,
  });

  const features = [
    {
      icon: <Shield className="w-12 h-12 text-red-500" />,
      title: 'Secure Storage',
      description: 'Your digital assets are protected with military-grade encryption'
    },
    {
      icon: <Rocket className="w-12 h-12 text-red-500" />,
      title: 'Tesla Shares',
      description: 'Invest in Tesla shares directly with your crypto assets'
    },
    {
      icon: <MessageCircle className="w-12 h-12 text-red-500" />,
      title: '24/7 Support',
      description: 'Our dedicated team is always ready to help you'
    },
    {
      icon: <Coins className="w-12 h-12 text-red-500" />,
      title: 'Multiple Assets',
      description: 'Trade Bitcoin, Ethereum, Solana, TON, and USDT'
    }
  ];

  return (
    <animated.div style={fadeIn} className="bg-black py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-white text-center mb-12">
          Why Choose Our Platform
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 text-center hover:bg-gray-800 transition-colors"
            >
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-400">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </animated.div>
  );
};