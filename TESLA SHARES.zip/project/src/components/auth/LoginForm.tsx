import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { generateRecoveryPhrase } from '../../utils/recoveryPhrase';
import { ArrowLeft, Gift } from 'lucide-react';
import { createNewUser } from '../../utils/userUtils';
import { validateLogin } from '../../utils/authUtils';
import { WelcomeBonus } from './WelcomeBonus';
import { LoginTabs } from './LoginTabs';
import { LoginInput } from './LoginInput';

interface LoginFormProps {
  isAdmin: boolean;
  onBack: () => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ isAdmin, onBack }) => {
  const [recoveryPhrase, setRecoveryPhrase] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isNewAccount, setIsNewAccount] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { setUser, users } = useAuthStore();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (isAdmin) {
        if (password === '00993366') {
          setUser({
            id: 'admin',
            username: 'Admin',
            role: 'admin',
            status: 'active',
            balance: { bitcoin: 0, ethereum: 0, solana: 0, ton: 0, usdt: 0, tesla: 0 }
          });
          navigate('/admin');
          return;
        }
        throw new Error('Invalid admin password');
      }

      if (isNewAccount) {
        if (!username.trim()) {
          throw new Error('Username is required');
        }

        const existingUser = users.find(u => u.username.toLowerCase() === username.toLowerCase());
        if (existingUser) {
          throw new Error('Username already exists. Please choose a different username.');
        }

        const newUser = createNewUser(username);
        setUser(newUser);
        navigate('/dashboard');
      } else {
        if (!recoveryPhrase.trim()) {
          throw new Error('Recovery phrase is required');
        }

        const loginResult = validateLogin(recoveryPhrase, users);
        if (!loginResult.success) {
          throw new Error(loginResult.error);
        }

        setUser({
          ...loginResult.user,
          profile: {
            ...loginResult.user.profile,
            hasSeenPhrase: true
          }
        });
        navigate('/dashboard');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  return (
    <div className="w-full max-w-md">
      <button
        onClick={onBack}
        className="flex items-center text-gray-400 hover:text-white mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back
      </button>

      <h2 className="text-2xl font-bold text-white mb-6">
        {isAdmin ? 'Admin Login' : (isNewAccount ? 'Create New Wallet' : 'Access Wallet')}
      </h2>

      {!isAdmin && isNewAccount && <WelcomeBonus />}

      {!isAdmin && (
        <LoginTabs
          isNewAccount={isNewAccount}
          onTabChange={setIsNewAccount}
        />
      )}

      <form onSubmit={handleLogin} className="space-y-4">
        {isAdmin ? (
          <LoginInput
            type="password"
            value={password}
            onChange={setPassword}
            placeholder="Admin Password"
          />
        ) : (
          <>
            {isNewAccount ? (
              <LoginInput
                type="text"
                value={username}
                onChange={setUsername}
                placeholder="Choose a username"
              />
            ) : (
              <LoginInput
                type="textarea"
                value={recoveryPhrase}
                onChange={setRecoveryPhrase}
                placeholder="Enter your 12-word recovery phrase"
                rows={3}
              />
            )}
          </>
        )}

        {error && (
          <p className="text-red-500 text-sm">{error}</p>
        )}

        <button
          type="submit"
          className="w-full py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
        >
          {isAdmin ? 'Login as Admin' : (isNewAccount ? 'Create Wallet' : 'Access Wallet')}
        </button>
      </form>
    </div>
  );
};