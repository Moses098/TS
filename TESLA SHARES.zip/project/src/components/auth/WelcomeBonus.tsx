import React from 'react';
import { Gift } from 'lucide-react';

export const WelcomeBonus: React.FC = () => {
  return (
    <div className="bg-red-600/20 border border-red-500/30 rounded-lg p-4 mb-6">
      <div className="flex items-center gap-2">
        <Gift className="text-red-500 w-5 h-5" />
        <p className="text-white font-medium">Welcome Bonus!</p>
      </div>
      <p className="text-sm text-red-200 mt-1">
        Get $2,000 in Bitcoin instantly + $5,000 bonus after $3,000 deposit
      </p>
    </div>
  );
};