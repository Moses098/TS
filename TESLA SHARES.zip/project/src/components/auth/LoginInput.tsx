import React from 'react';

interface LoginInputProps {
  type: 'text' | 'password' | 'textarea';
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  rows?: number;
}

export const LoginInput: React.FC<LoginInputProps> = ({
  type,
  value,
  onChange,
  placeholder,
  rows
}) => {
  const baseClassName = "w-full px-4 py-2 bg-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500";

  if (type === 'textarea') {
    return (
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className={baseClassName}
      />
    );
  }

  return (
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={baseClassName}
    />
  );
};