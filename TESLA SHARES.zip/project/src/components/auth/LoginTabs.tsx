import React from 'react';

interface LoginTabsProps {
  isNewAccount: boolean;
  onTabChange: (isNew: boolean) => void;
}

export const LoginTabs: React.FC<LoginTabsProps> = ({ isNewAccount, onTabChange }) => {
  return (
    <div className="flex space-x-4 mb-6">
      <button
        onClick={() => onTabChange(true)}
        className={`flex-1 py-2 px-4 rounded-lg transition-colors ${
          isNewAccount ? 'bg-red-600 text-white' : 'bg-gray-700 text-gray-300'
        }`}
      >
        New Account
      </button>
      <button
        onClick={() => onTabChange(false)}
        className={`flex-1 py-2 px-4 rounded-lg transition-colors ${
          !isNewAccount ? 'bg-red-600 text-white' : 'bg-gray-700 text-gray-300'
        }`}
      >
        Access Wallet
      </button>
    </div>
  );
};