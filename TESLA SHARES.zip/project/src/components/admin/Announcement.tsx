import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { useMessageStore } from '../../store/messageStore';
import { useAuthStore } from '../../store/authStore';

export const Announcement: React.FC = () => {
  const [message, setMessage] = useState('');
  const { broadcastAnnouncement } = useMessageStore();
  const { users } = useAuthStore();

  const handleSendAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const customerIds = users
      .filter(user => user.role === 'customer')
      .map(user => user.id);

    broadcastAnnouncement(message, customerIds);
    setMessage('');
    alert('Announcement sent to all users');
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <h3 className="text-xl font-bold text-white mb-4">Send Announcement</h3>
      <form onSubmit={handleSendAnnouncement} className="space-y-4">
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your announcement message..."
          rows={4}
          className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500"
        />
        <button
          type="submit"
          className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
        >
          <Send className="w-4 h-4" />
          Send to All Users
        </button>
      </form>
    </div>
  );
};