import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import { useAuthStore } from '../../store/authStore';

interface BalanceEditorProps {
  customer: User;
}

export const BalanceEditor: React.FC<BalanceEditorProps> = ({ customer }) => {
  const { updateUserBalance } = useAuthStore();
  const [balance, setBalance] = useState(customer.balance);

  useEffect(() => {
    setBalance(customer.balance);
  }, [customer]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserBalance(customer.id, balance);
    alert('Balance updated successfully!');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Object.entries(balance).map(([asset, value]) => (
          <div key={asset} className="space-y-2">
            <label className="block text-sm font-medium text-gray-400 capitalize">
              {asset === 'tesla' ? 'Tesla Shares' : `${asset} Balance`}
            </label>
            <input
              type="number"
              min="0"
              step={asset === 'tesla' ? '1' : '0.000001'}
              value={value}
              onChange={(e) =>
                setBalance((prev) => ({
                  ...prev,
                  [asset]: parseFloat(e.target.value) || 0,
                }))
              }
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
        ))}
      </div>
      <button
        type="submit"
        className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
      >
        Update Balance
      </button>
    </form>
  );
};