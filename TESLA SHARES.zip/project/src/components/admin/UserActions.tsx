import React from 'react';
import { Ban, UserX, AlertTriangle, MessageSquare } from 'lucide-react';
import { User } from '../../types';
import { useAuthStore } from '../../store/authStore';

interface UserActionsProps {
  customer: User;
}

export const UserActions: React.FC<UserActionsProps> = ({ customer }) => {
  const { updateUserStatus, deleteUser } = useAuthStore();

  const handleStatusChange = (status: 'active' | 'suspended' | 'banned') => {
    if (window.confirm(`Are you sure you want to ${status} this user?`)) {
      updateUserStatus(customer.id, status);
    }
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      deleteUser(customer.id);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button
          onClick={() => handleStatusChange('active')}
          className={`flex-1 px-4 py-2 rounded-lg ${
            customer.status === 'active'
              ? 'bg-green-600 text-white'
              : 'bg-gray-700 text-gray-300'
          }`}
        >
          Activate
        </button>
        <button
          onClick={() => handleStatusChange('suspended')}
          className={`flex-1 px-4 py-2 rounded-lg ${
            customer.status === 'suspended'
              ? 'bg-yellow-600 text-white'
              : 'bg-gray-700 text-gray-300'
          }`}
        >
          <AlertTriangle className="w-4 h-4 inline-block mr-2" />
          Suspend
        </button>
        <button
          onClick={() => handleStatusChange('banned')}
          className={`flex-1 px-4 py-2 rounded-lg ${
            customer.status === 'banned'
              ? 'bg-red-600 text-white'
              : 'bg-gray-700 text-gray-300'
          }`}
        >
          <Ban className="w-4 h-4 inline-block mr-2" />
          Ban
        </button>
      </div>
      <button
        onClick={handleDelete}
        className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
      >
        <UserX className="w-4 h-4 inline-block mr-2" />
        Delete Account
      </button>
    </div>
  );
};