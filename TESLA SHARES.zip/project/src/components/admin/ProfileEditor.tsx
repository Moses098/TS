import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import { useAuthStore } from '../../store/authStore';

interface ProfileEditorProps {
  customer: User;
}

export const ProfileEditor: React.FC<ProfileEditorProps> = ({ customer }) => {
  const { updateUserProfile } = useAuthStore();
  const [profile, setProfile] = useState({
    email: customer.profile?.email || '',
    fullName: customer.profile?.fullName || '',
    country: customer.profile?.country || '',
  });

  useEffect(() => {
    setProfile({
      email: customer.profile?.email || '',
      fullName: customer.profile?.fullName || '',
      country: customer.profile?.country || '',
    });
  }, [customer]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile(customer.id, {
      ...customer.profile,
      ...profile,
    });
    alert('Profile updated successfully!');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-1">
          Full Name
        </label>
        <input
          type="text"
          value={profile.fullName}
          onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
          className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-1">
          Email
        </label>
        <input
          type="email"
          value={profile.email}
          onChange={(e) => setProfile({ ...profile, email: e.target.value })}
          className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-1">
          Country
        </label>
        <input
          type="text"
          value={profile.country}
          onChange={(e) => setProfile({ ...profile, country: e.target.value })}
          className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
        />
      </div>
      <button
        type="submit"
        className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
      >
        Update Profile
      </button>
    </form>
  );
};