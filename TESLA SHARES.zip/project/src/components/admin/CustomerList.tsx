import React from 'react';
import { User } from '../../types';
import { Users } from 'lucide-react';

interface CustomerListProps {
  customers: User[];
  selectedUser: string;
  onSelectUser: (userId: string) => void;
}

export const CustomerList: React.FC<CustomerListProps> = ({
  customers,
  selectedUser,
  onSelectUser,
}) => {
  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center gap-3 mb-6">
        <Users className="text-red-500 w-6 h-6" />
        <h3 className="text-xl font-bold text-white">Customers</h3>
      </div>
      <div className="space-y-2">
        {customers.map((customer) => (
          <button
            key={customer.id}
            onClick={() => onSelectUser(customer.id)}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              selectedUser === customer.id
                ? 'bg-red-600 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-medium">{customer.username}</span>
              <span className="text-sm opacity-75">
                {new Date(customer.profile?.joinedAt || '').toLocaleDateString()}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};