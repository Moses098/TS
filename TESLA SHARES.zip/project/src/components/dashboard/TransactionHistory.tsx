import React from 'react';
import { ArrowUpRight, ArrowDownLeft, Send, Gift } from 'lucide-react';
import { useTransactionStore } from '../../store/transactionStore';
import { formatCurrency } from '../../utils/balanceUtils';
import { Transaction, User } from '../../types';

interface TransactionHistoryProps {
  user: User;
}

const TransactionIcon = ({ type }: { type: Transaction['type'] }) => {
  switch (type) {
    case 'deposit':
      return <ArrowDownLeft className="w-5 h-5 text-green-500" />;
    case 'withdrawal':
      return <ArrowUpRight className="w-5 h-5 text-red-500" />;
    case 'transfer':
      return <Send className="w-5 h-5 text-blue-500" />;
    case 'bonus':
      return <Gift className="w-5 h-5 text-yellow-500" />;
  }
};

export const TransactionHistory: React.FC<TransactionHistoryProps> = ({ user }) => {
  const { getTransactions } = useTransactionStore();
  const transactions = getTransactions(user.id);

  if (transactions.length === 0) {
    return null;
  }

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <h3 className="text-xl font-bold text-white mb-6">Transaction History</h3>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div
            key={transaction.id}
            className="flex items-center justify-between bg-gray-700/50 rounded-lg p-4"
          >
            <div className="flex items-center gap-4">
              <TransactionIcon type={transaction.type} />
              <div>
                <p className="text-white font-medium capitalize">
                  {transaction.type} {transaction.asset}
                </p>
                <p className="text-sm text-gray-400">
                  {new Date(transaction.timestamp).toLocaleString()}
                </p>
                {transaction.description && (
                  <p className="text-sm text-gray-400">{transaction.description}</p>
                )}
              </div>
            </div>
            <div className="text-right">
              <p className={`font-medium ${
                transaction.type === 'deposit' || transaction.type === 'bonus'
                  ? 'text-green-500'
                  : 'text-red-500'
              }`}>
                {transaction.type === 'deposit' || transaction.type === 'bonus' ? '+' : '-'}
                {transaction.amount} {transaction.asset.toUpperCase()}
              </p>
              <p className={`text-sm ${
                transaction.status === 'completed'
                  ? 'text-green-400'
                  : transaction.status === 'pending'
                  ? 'text-yellow-400'
                  : 'text-red-400'
              }`}>
                {transaction.status}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};