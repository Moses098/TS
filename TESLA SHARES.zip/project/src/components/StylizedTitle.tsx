import React from 'react';

export const StylizedTitle: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`${className} relative group perspective-1000`}>
      <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-red-600 to-red-700 
        transform-gpu transition-transform duration-300 group-hover:scale-105
        after:content-[attr(data-text)] after:absolute after:left-0 after:top-0
        after:z-[-1] after:transform-gpu after:translate-z-12 after:text-red-900/20"
        style={{
          textShadow: `
            0 1px 0 #cc0000,
            0 2px 0 #b30000,
            0 3px 0 #990000,
            0 4px 0 #800000,
            0 5px 10px rgba(0, 0, 0, 0.6)
          `
        }}
      >
        TESLA SHARES INVESTMENT
      </h1>
    </div>
  );
};