import { User } from '../types';
import { generateRecoveryPhrase } from './recoveryPhrase';

export const createNewUser = (username: string): User => {
  return {
    id: crypto.randomUUID(),
    username,
    role: 'customer',
    status: 'active',
    phrase: generateRecoveryPhrase(),
    balance: {
      bitcoin: 0.05, // Initial $2,000 bonus in Bitcoin
      ethereum: 0,
      solana: 0,
      ton: 0,
      usdt: 0,
      tesla: 0
    },
    profile: {
      email: '',
      fullName: username,
      country: '',
      joinedAt: new Date().toISOString(),
      hasSeenPhrase: false
    }
  };
};