import { User } from '../types';

interface LoginValidationResult {
  success: boolean;
  error?: string;
  user?: User;
}

export const validateLogin = (
  recoveryPhrase: string,
  users: User[]
): LoginValidationResult => {
  const user = users.find(u => u.phrase === recoveryPhrase);

  if (!user) {
    return {
      success: false,
      error: 'Invalid recovery phrase'
    };
  }

  if (user.status === 'banned') {
    return {
      success: false,
      error: 'This account has been banned. Please contact support.'
    };
  }

  if (user.status === 'suspended') {
    return {
      success: false,
      error: 'This account has been suspended. Please contact support.'
    };
  }

  return {
    success: true,
    user
  };
};