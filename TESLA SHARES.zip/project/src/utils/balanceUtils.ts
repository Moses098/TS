import { User } from '../types';
import { useCryptoRates } from '../services/cryptoRates';

export const calculateTotalAssetValue = (balance: Record<string, number>, rates: Record<string, number>): number => {
  const { tesla, ...cryptoBalances } = balance;
  return Object.entries(cryptoBalances).reduce((sum, [asset, amount]) => {
    return sum + (amount * (rates[asset] || 0));
  }, 0) + (tesla * 180.75); // Tesla share price
};

export const hasMinimumBalance = (balance: Record<string, number>, rates: Record<string, number>): boolean => {
  const totalValue = calculateTotalAssetValue(balance, rates);
  return totalValue > 0;
};

export const hasMinimumWithdrawBalance = (balance: Record<string, number>, rates: Record<string, number>): boolean => {
  const totalValue = calculateTotalAssetValue(balance, rates);
  return totalValue >= 10000; // Minimum $10,000 for withdrawals
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};